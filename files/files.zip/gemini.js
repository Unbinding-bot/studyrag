// Gemini API client
// All real API calls live here — no stubs.

const BASE = "https://generativelanguage.googleapis.com/v1beta";

// ── helpers ───────────────────────────────────────────────────────────────────

function geminiHeaders(apiKey) {
  return { "Content-Type": "application/json", "x-goog-api-key": apiKey };
}

async function geminiPost(path, apiKey, body) {
  const r = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: geminiHeaders(apiKey),
    body: JSON.stringify(body),
  });
  if (!r.ok) {
    const err = await r.json().catch(() => ({}));
    throw new Error(err?.error?.message || `Gemini error ${r.status}`);
  }
  return r.json();
}

// ── text extraction ───────────────────────────────────────────────────────────

export async function extractText(file) {
  const ext = file.name.split(".").pop().toLowerCase();

  if (ext === "txt" || ext === "md") {
    return file.text();
  }

  if (ext === "pdf") {
    // Use pdf.js (loaded via CDN in index.html)
    const ab = await file.arrayBuffer();
    const pdfjsLib = window["pdfjs-dist/build/pdf"];
    pdfjsLib.GlobalWorkerOptions.workerSrc =
      "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
    const pdf = await pdfjsLib.getDocument({ data: ab }).promise;
    let text = "";
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      text += `\n[Page ${i}]\n` + content.items.map((it) => it.str).join(" ");
    }
    return text;
  }

  if (ext === "docx") {
    const ab = await file.arrayBuffer();
    const mammoth = window.mammoth;
    if (!mammoth) throw new Error("mammoth.js not loaded");
    const result = await mammoth.extractRawText({ arrayBuffer: ab });
    return result.value;
  }

  if (["png", "jpg", "jpeg", "webp", "gif"].includes(ext)) {
    // Return a marker — images go directly to Gemini vision, not chunked
    return `[IMAGE:${file.name}]`;
  }

  // pptx / other: best-effort binary text (will be noisy but better than nothing)
  return `[Unsupported format: ${file.name}. Text extraction not available for this file type. Upload a PDF, DOCX, or TXT for full RAG support.]`;
}

// ── chunking ──────────────────────────────────────────────────────────────────

export function chunkText(text, { chunkSize = 512, overlap = 64, strategy = "semantic" } = {}) {
  if (strategy === "page") {
    // Split on [Page N] markers
    const pages = text.split(/\[Page \d+\]/);
    return pages
      .map((p, i) => p.trim())
      .filter((p) => p.length > 20)
      .map((p, i) => ({ text: p, page: i + 1 }));
  }

  if (strategy === "semantic") {
    // Split on paragraph boundaries first, then merge to chunkSize
    const paras = text.split(/\n{2,}/);
    const chunks = [];
    let current = "";
    let startPara = 0;

    for (let i = 0; i < paras.length; i++) {
      const para = paras[i].trim();
      if (!para) continue;
      if ((current + " " + para).length > chunkSize * 4 && current.length > 0) {
        chunks.push({ text: current.trim(), paraStart: startPara, paraEnd: i - 1 });
        // overlap: keep last overlap chars
        current = current.slice(-overlap * 4) + " " + para;
        startPara = i;
      } else {
        current += (current ? " " : "") + para;
      }
    }
    if (current.trim()) chunks.push({ text: current.trim(), paraStart: startPara, paraEnd: paras.length });
    return chunks;
  }

  // fixed-size
  const words = text.split(/\s+/);
  const chunks = [];
  for (let i = 0; i < words.length; i += chunkSize - overlap) {
    const slice = words.slice(i, i + chunkSize).join(" ");
    if (slice.trim()) chunks.push({ text: slice });
  }
  return chunks;
}

// ── embeddings ────────────────────────────────────────────────────────────────

export async function embedTexts(texts, apiKey) {
  // Gemini embedding-001 supports batch up to 100
  const BATCH = 100;
  const all = [];
  for (let i = 0; i < texts.length; i += BATCH) {
    const batch = texts.slice(i, i + BATCH);
    const body = {
      requests: batch.map((t) => ({
        model: "models/embedding-001",
        content: { parts: [{ text: t }] },
        taskType: "RETRIEVAL_DOCUMENT",
      })),
    };
    const data = await geminiPost("/models/embedding-001:batchEmbedContents", apiKey, body);
    all.push(...data.embeddings.map((e) => e.values));
  }
  return all;
}

export async function embedQuery(text, apiKey) {
  const data = await geminiPost("/models/embedding-001:embedContent", apiKey, {
    model: "models/embedding-001",
    content: { parts: [{ text }] },
    taskType: "RETRIEVAL_QUERY",
  });
  return data.embedding.values;
}

// ── cosine similarity ─────────────────────────────────────────────────────────

export function cosineSim(a, b) {
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  return dot / (Math.sqrt(na) * Math.sqrt(nb) + 1e-10);
}

export function topK(queryVec, chunks, k = 5) {
  return chunks
    .map((c) => ({ ...c, score: cosineSim(queryVec, c.embedding) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, k);
}

// ── RAG Q&A ───────────────────────────────────────────────────────────────────

export async function ragAnswer({ question, chunks, apiKey, model = "gemini-1.5-flash", onChunk }) {
  const context = chunks.map((c, i) => `[Source ${i + 1} | Doc: ${c.docName} | Page: ${c.page || "?"}]\n${c.text}`).join("\n\n---\n\n");

  const systemPrompt = `You are a study assistant. Answer ONLY using the provided document excerpts below. If the answer is not in the documents, say so clearly. Be precise, thorough, and cite which source you're drawing from (e.g. "According to Source 2...").

DOCUMENTS:
${context}`;

  const url = `${BASE}/models/${model}:streamGenerateContent?alt=sse`;
  const body = {
    contents: [{ role: "user", parts: [{ text: question }] }],
    systemInstruction: { parts: [{ text: systemPrompt }] },
    generationConfig: { temperature: 0.2, maxOutputTokens: 2048 },
  };

  const r = await fetch(url, {
    method: "POST",
    headers: geminiHeaders(apiKey),
    body: JSON.stringify(body),
  });

  if (!r.ok) {
    const err = await r.json().catch(() => ({}));
    throw new Error(err?.error?.message || `Gemini error ${r.status}`);
  }

  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let full = "";
  let buf = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop();
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const json = line.slice(6).trim();
      if (json === "[DONE]") continue;
      try {
        const parsed = JSON.parse(json);
        const text = parsed?.candidates?.[0]?.content?.parts?.[0]?.text || "";
        full += text;
        onChunk?.(text, full);
      } catch {}
    }
  }
  return full;
}

// ── Subject naming ────────────────────────────────────────────────────────────

export async function nameSubject(docNames, apiKey) {
  const data = await geminiPost(`/models/gemini-1.5-flash:generateContent`, apiKey, {
    contents: [{ role: "user", parts: [{ text: `Given these uploaded file names, generate a concise and descriptive subject/topic name (3-6 words max, title case). Files: ${docNames.join(", ")}. Reply with ONLY the name, nothing else.` }] }],
    generationConfig: { temperature: 0.4, maxOutputTokens: 32 },
  });
  return data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || "New Subject";
}

// ── Quiz generation ───────────────────────────────────────────────────────────

export async function generateQuiz({ chunks, config, apiKey, model = "gemini-1.5-flash" }) {
  const context = chunks.map((c, i) => `[${c.docName} | p.${c.page || "?"}]\n${c.text}`).join("\n\n---\n\n");

  const types = [];
  if (config.types.mc) types.push(`- multiple_choice: exactly 4 options (A/B/C/D), "correctIndex": 0-3`);
  if (config.types.tf) types.push(`- true_false: "answer": true or false${config.modifiedTF ? ', "requireExplanation": true (user must explain if false)' : ""}`);
  if (config.types.freeform) types.push(`- freeform: open-ended, "modelAnswer": a full ideal answer, "rubric": key points to check`);

  const prompt = `You are a rigorous academic quiz generator. Generate exactly ${config.numQ} quiz questions based ONLY on the document excerpts below.

Question type distribution: ${types.join("; ")}
Mix types evenly unless only one is selected.
${config.geminiTime && config.timerMode === "perq" ? 'For each question add "suggestedSeconds": estimated seconds to answer based on complexity and typing time.' : ""}

Respond ONLY with a valid JSON array. No markdown, no explanation. Each item:
{
  "type": "multiple_choice" | "true_false" | "freeform",
  "question": "...",
  "docName": "source document name",
  "page": page number or null,
  "difficulty": "easy" | "medium" | "hard",
  // for multiple_choice:
  "options": ["A","B","C","D"],
  "correctIndex": 0,
  "explanation": "why this is correct",
  // for true_false:
  "answer": true,
  "explanation": "...",
  "requireExplanation": false,
  // for freeform:
  "modelAnswer": "...",
  "rubric": ["key point 1", "key point 2"],
  "explanation": "..."
  ${config.geminiTime && config.timerMode === "perq" ? ', "suggestedSeconds": 45' : ""}
}

DOCUMENTS:
${context}`;

  const data = await geminiPost(`/models/${model}:generateContent`, apiKey, {
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.5, maxOutputTokens: 8192 },
  });

  const raw = data.candidates?.[0]?.content?.parts?.[0]?.text || "[]";
  const clean = raw.replace(/```json|```/g, "").trim();
  try {
    return JSON.parse(clean);
  } catch {
    // Try to extract JSON array
    const match = clean.match(/\[[\s\S]*\]/);
    if (match) return JSON.parse(match[0]);
    throw new Error("Gemini returned invalid JSON for quiz. Try again.");
  }
}

// ── Freeform answer grading ───────────────────────────────────────────────────

export async function gradeFreeform({ question, modelAnswer, rubric, userAnswer, apiKey, model = "gemini-1.5-flash" }) {
  const prompt = `You are a brutally honest academic grader. Grade this student answer.

Question: ${question}
Model Answer: ${modelAnswer}
Rubric points to cover: ${rubric.join(", ")}
Student Answer: ${userAnswer}

Respond ONLY with JSON:
{
  "score": 0-100,
  "correct": true/false,
  "feedback": "detailed, honest feedback about what they got right and wrong",
  "missedPoints": ["rubric point they missed"],
  "hitPoints": ["rubric point they nailed"]
}`;

  const data = await geminiPost(`/models/${model}:generateContent`, apiKey, {
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.1, maxOutputTokens: 512 },
  });

  const raw = data.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
  const clean = raw.replace(/```json|```/g, "").trim();
  try { return JSON.parse(clean); }
  catch { return { score: 0, correct: false, feedback: raw, missedPoints: [], hitPoints: [] }; }
}

// ── Study chat ────────────────────────────────────────────────────────────────

export async function studyChat({ messages, chunks, apiKey, model = "gemini-1.5-flash", onChunk }) {
  const context = chunks.map((c, i) => `[Source ${i + 1} | Doc: ${c.docName} | Page: ${c.page || "?"}]\n${c.text}`).join("\n\n---\n\n");

  const system = `You are a helpful, precise study assistant. Answer ONLY using the provided document excerpts. Never make up information not in the documents. When you answer, at the end of your response include a JSON block in this exact format on its own line so the UI can show a "view source" button:
SOURCES_JSON:{"docName":"...","page":1,"snippet":"first 80 chars of the relevant text"}

DOCUMENTS:
${context}`;

  const url = `${BASE}/models/${model}:streamGenerateContent?alt=sse`;
  const body = {
    contents: messages.map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] })),
    systemInstruction: { parts: [{ text: system }] },
    generationConfig: { temperature: 0.2, maxOutputTokens: 2048 },
  };

  const r = await fetch(url, {
    method: "POST",
    headers: geminiHeaders(apiKey),
    body: JSON.stringify(body),
  });

  if (!r.ok) {
    const err = await r.json().catch(() => ({}));
    throw new Error(err?.error?.message || `Gemini error ${r.status}`);
  }

  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let full = "";
  let buf = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop();
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const json = line.slice(6).trim();
      if (json === "[DONE]") continue;
      try {
        const parsed = JSON.parse(json);
        const text = parsed?.candidates?.[0]?.content?.parts?.[0]?.text || "";
        full += text;
        onChunk?.(text, full);
      } catch {}
    }
  }
  return full;
}

export function parseSourcesFromReply(text) {
  const match = text.match(/SOURCES_JSON:(\{[^\n]+\})/);
  if (!match) return null;
  try { return JSON.parse(match[1]); }
  catch { return null; }
}

export function stripSourcesJson(text) {
  return text.replace(/\nSOURCES_JSON:[^\n]+/, "").trim();
}
