# StudyRAG

A fully local, browser-based RAG study app. Upload your documents, chat with them, quiz yourself, and study with cited source-jumping — all powered by your own Gemini API key, zero server required.

---

## Quick Start

```bash
npm install
npm run dev
# → http://localhost:5173
```

Then open Settings (gear icon, top-right), enter your Gemini API key, and create your first subject.

Get a free API key at: https://aistudio.google.com/app/apikey

---

## Project Structure

```
studyrag/
├── index.html                    # Loads pdf.js + mammoth.js from CDN
├── vite.config.js
├── package.json
└── src/
    ├── main.jsx                  # React root, wraps app in AppProvider
    ├── App.jsx                   # Shell: layout, sidebar, modals, exports shared utils
    ├── lib/
    │   ├── db.js                 # IndexedDB wrapper (subjects, docs, chunks, tests, settings)
    │   ├── gemini.js             # All Gemini API: embed, RAG, quiz gen, grading, stream chat
    │   ├── themes.js             # 8 dark + 4 light themes, 52-font list
    │   └── context.jsx           # React context: settings, theme, save helpers
    └── pages/
        ├── SubjectHome.jsx       # Doc list, add/remove, rename, delete, mode launcher
        ├── QAMode.jsx            # Streaming RAG chat with source panel
        ├── QuizMode.jsx          # Quiz config, test taker, timer, grading, history
        └── StudyMode.jsx         # Split view: PDF/doc viewer + cited RAG chat
```

---

## How RAG Works

### On document upload

```
File → extract text (pdf.js / mammoth / raw)
     → chunk into overlapping segments
     → embed each chunk via Gemini embedding-001
     → store chunks + vectors in IndexedDB
```

### On every query

```
Question → embed query → cosine similarity vs all chunk vectors
         → top-K chunks selected → sent as context to Gemini
         → streamed response rendered token by token
```

### Fallback (no embeddings / no API key)

If embedding fails or no key is set, keyword search is used automatically — still useful, just less semantic.

---

## Features

### Subjects

- Create, rename, delete subjects
- Auto-naming: with an API key, Gemini names the subject from your file names (toggle on/off)
- Each subject has its own isolated documents, chunks, and saved tests

### Documents

Supported formats:

| Format | Text indexed | Viewer |
|--------|-------------|--------|
| PDF    | ✅ pdf.js (text + page numbers) | ✅ Canvas, zoom, page nav |
| DOCX/DOC | ✅ mammoth.js | ✅ Extracted text + snippet highlight |
| TXT/MD | ✅ Native | ✅ Text viewer + highlight |
| PNG/JPG/WEBP/GIF | ❌ (no text) | ✅ Image viewer with zoom |
| PPTX | ⚠ Best-effort text | ✅ Text fallback |

- Add files from Subject Home or the New Subject dialog
- Remove a document with the trash icon — also deletes its embeddings
- Files stored as base64 in IndexedDB for the viewer

### Q&A Mode

Streaming chat that answers **only from your documents**.

- Question embedded → top-K chunks retrieved → streamed answer
- Expandable **Sources** panel per message: doc name, page, relevance %, snippet preview
- Keyword fallback if embedding fails
- Clear chat button
- Enter to send, Shift+Enter for newline

### Quiz / Test Mode

#### Configure tab

**Question types** (mix any combination):
- **Multiple Choice** — 4 options, Gemini writes distractors
- **True / False** — standard
- **Modified T/F** — user must type an explanation if they pick False
- **Freeform text** — open answer, Gemini grades it 0–100 with detailed feedback

**Number of questions:** 1–50

**Feedback:**
- Explain correct answers — on/off
- Explain wrong answers — on/off
- (Both on by default)

**Timer modes:**
- No timer
- Whole-test countdown — set total minutes; auto-finishes at zero
- Per-question countdown — set seconds per question OR let Gemini estimate time based on complexity

**Stopwatch:** Records total time, shown on results screen. Works with or without a timer.

**Pause:** Freezes all timers and hides question content.

**Test name:** Optional label shown in History.

#### Take Test tab

- Progress bar
- Big per-question countdown next to the question (per-q mode)
- Compact whole-test countdown in the header (whole mode)
- Stopwatch elapsed time
- MC: click option → Check answer → green correct / red wrong + explanation
- T/F: tap True/False buttons → reveal with Modified T/F explanation field if needed
- Freeform: type → Grade answer → Gemini returns score, feedback, hit/missed rubric points, model answer available as spoiler
- Previous / Next navigation (review answered questions)
- Finish at any time

#### Results screen

- Score fraction + percentage
- Color-coded progress bar (green ≥80%, yellow ≥60%, red <60%)
- Total stopwatch time (if enabled)
- Retake or Back to config

#### History tab

- Every generated test auto-saved to IndexedDB
- Load & Retake: restores exact questions and config
- Delete individual tests

### Study Mode

Split-panel layout: **document viewer (left) + RAG chat (right)**.

#### Document viewer

- Browser-style back/forward history
- Address bar showing current document
- Document tabs for quick switching
- PDF: canvas rendering, page nav (←/→), zoom (−/+)
- Images: zoom controls
- Text files: full text with snippet highlighting

#### View Source

After each AI message, a **📍 View source** button appears showing the document and page number. Clicking it:
1. Navigates the viewer to that document
2. Jumps to the correct page (PDF) or scrolls to the highlighted snippet (text files)
3. Green highlight flashes for 3.5 seconds, then fades

#### Chat

- Same RAG pipeline as Q&A (embed → top-K → stream)
- Gemini includes a `SOURCES_JSON` block in its response that is parsed and stripped before display
- Keyword fallback if needed

---

## Settings

### General

| Setting | Description |
|---------|-------------|
| Gemini API Key | Stored in IndexedDB only. Never sent anywhere but Google. |
| Model | gemini-1.5-flash (recommended), gemini-1.5-pro, gemini-2.0-flash, gemini-2.0-flash-thinking-exp |

### Appearance

**8 dark themes:** Obsidian, Forest, Crimson, Amber, Sapphire, Violet, Teal, Slate

**4 light themes:** Paper, Meadow, Blush, Sand

Themes apply instantly via CSS variables, no reload needed.

**52 fonts** covering sans-serif, serif, monospace, and display/handwriting styles including:
- Sans: Outfit, DM Sans, Syne, Karla, Nunito, Lato, Raleway, Cabin, Barlow, Exo 2, Rubik, Manrope, Plus Jakarta Sans, Lexend, Quicksand, Josefin Sans, Poppins, Work Sans, Mulish, IBM Plex Sans
- Serif: Merriweather, Playfair Display, Libre Baskerville, PT Serif, Lora, Source Serif 4, Crimson Pro, EB Garamond, Cormorant Garamond
- Mono: IBM Plex Mono, JetBrains Mono, Fira Code, Source Code Pro, Space Mono, Courier Prime, Anonymous Pro, Inconsolata, Roboto Mono, Ubuntu Mono, Share Tech Mono, Azeret Mono, Red Hat Mono
- Fun: Comic Neue, Pacifico, Permanent Marker, Special Elite, Caveat, Kalam, Patrick Hand, Architects Daughter

Live preview shown below the selector.

### RAG / AI

| Setting | Default | Notes |
|---------|---------|-------|
| Chunk size (words) | 512 | Smaller = more precise retrieval. Larger = richer per-chunk context. |
| Chunk overlap (words) | 64 | Words shared between adjacent chunks to avoid cutting context at boundaries. |
| Top-K | 5 | Chunks sent to Gemini per query. More = richer context, more tokens. |
| Temperature | 0.2 | 0 = factual, 1 = creative. Keep at 0.1–0.3 for study use. |
| Embedding strategy | Semantic | Semantic (paragraph-aware), Fixed-size (word count), Page-based (PDFs) |

⚠ Changing RAG settings only affects newly added documents. Remove and re-add to reprocess existing ones.

---

## IndexedDB Schema

**Database:** `studyrag` v2

### `subjects`
```
{ id, name, createdAt, updatedAt, docCount }
```

### `documents` (index: subjectId)
```
{ id, subjectId, name, type, size, addedAt, fileData (base64), mimeType }
```

### `chunks` (indexes: docId, subjectId)
```
{ id (auto), subjectId, docId, docName, text, page, embedding (float[] | null) }
```

### `tests` (index: subjectId)
```
{ id, subjectId, name, config, questions, createdAt }
```

### `settings`
```
{ key, value }
Keys: apiKey, colorTheme, font, model, chunkSize, chunkOverlap, topK, temperature, embedStrategy
```

---

## Gemini Free Tier (mid-2025)

| Model | RPM | TPD |
|-------|-----|-----|
| gemini-1.5-flash | 15 | 1,500 |
| gemini-1.5-pro | 2 | 50 |
| embedding-001 | 1,500 RPM | — |

**gemini-1.5-flash** is the right default — fast, free, and capable.

Token cost per operation:
- Q&A query: ~500–2,500 tokens (depends on chunk size × top-K)
- Quiz generation: ~3,000–8,000 tokens (40 chunks + system prompt + JSON)
- Freeform grading: ~300–600 tokens per answer
- Study chat: similar to Q&A

---

## Deploy Live

```bash
npm run build    # → dist/
```

**Vercel:**
```bash
npx vercel --prod
```

**Netlify:**
```bash
npx netlify deploy --prod --dir=dist
```

**GitHub Pages** — add to `vite.config.js`:
```js
base: '/your-repo-name/'
```
Then push `dist/` to the `gh-pages` branch.

**nginx:**
```nginx
location / {
  root /var/www/studyrag/dist;
  try_files $uri $uri/ /index.html;
}
```

The app is entirely static. Each user brings their own API key. Data is local to each user's browser — no accounts, no sync.

---

## Extending

### Add a theme

In `src/lib/themes.js`, add to `DARK_THEMES` or `LIGHT_THEMES`:

```js
{
  id: "my-theme", label: "My Theme",
  accent: "#hex", accentFg: "#hex",   // text on accent bg
  bg: "#hex", surface: "#hex", surface2: "#hex",
  border: "#hex", text: "#hex", muted: "#hex",
}
```

### Add a font

Add its name to the `FONTS` array in `src/lib/themes.js`. It loads from Google Fonts automatically.

### Add a question type

1. Add a key to `DEFAULT_CONFIG.types` in `QuizMode.jsx`
2. Add a `Toggle` for it in `ConfigPanel`
3. Describe the JSON shape for the new type in the `generateQuiz` prompt in `gemini.js`
4. Add a rendering block for the new `q.type` in `TestTaker`

### Add cloud sync

Replace `db.js` calls with API calls to any backend (Supabase, Firebase, PocketBase). Keep IndexedDB as a local cache for offline use.

### Improve citation accuracy

Currently, source jumping uses the `docName` and `page` returned by Gemini (which is approximately correct). For exact accuracy:
1. Store character offsets when chunking
2. After each answer, find the best-matching chunk by text similarity
3. Use stored offsets to highlight the exact span in the viewer

---

## Troubleshooting

**"No document chunks found"**
Make sure you've added documents AND that your API key was set at the time of adding (embedding happens at upload time). If you added docs before setting the key, remove and re-add them.

**PDF pages are blank**
pdf.js loads from CDN. Check your internet connection. Very large PDFs (150+ pages) may be slow.

**Quiz returns invalid JSON**
Gemini occasionally fails on complex multi-type configs. Retry, reduce question count, or use a single question type.

**Embedding rate limit (429)**
You've hit 1,500 requests/day on embedding-001. Wait 24 hours or use a different API key. Keyword fallback activates automatically.

**DOCX shows garbled text**
mammoth.js handles standard .docx well but may struggle with heavily formatted files. Use PDF for best results.

**Settings not saving**
Some browsers block IndexedDB in private/incognito mode. Use a normal window.
